package com.konasl.ib.webbankingserver

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class WebBankingServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
